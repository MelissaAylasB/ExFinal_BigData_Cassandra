from flask import Flask, render_template, abort
from cassandra.cluster import Cluster
from cassandra.query import dict_factory
from flask import Flask, render_template, abort, request, redirect, url_for
from uuid import UUID


# --- Conexión a Cassandra ---
cluster = Cluster(["172.17.0.2"], port=9042)
session = cluster.connect("proyecto_final")
session.row_factory = dict_factory

app = Flask(__name__)


# ---------- HELPERS DE CONSULTA ----------
def insert_student_event(student_id_str, video_id_str, event_type, second_mark, comment_text):
    student_id = UUID(student_id_str)
    video_id = UUID(video_id_str)
    session.execute(
        """
        INSERT INTO experience_by_student_video (
            student_id, video_id, event_time, event_type, second_mark, comment_text
        ) VALUES (%s, %s, toTimestamp(now()), %s, %s, %s)
        """,
        (student_id, video_id, event_type, int(second_mark), comment_text),
    )

def get_all_videos():
    rows = session.execute(
        "SELECT course_id, video_id, title FROM videos_by_course"
    )
    return list(rows)

def get_courses():
    """Devuelve cursos del programa ING-SOFT en el periodo 2025-1."""
    rows = session.execute(
        """
        SELECT course_id, global_friction_index
        FROM course_summary_by_program_period
        WHERE program_id = 'ING-SOFT' AND period_id = '2025-1'
        """
    )
    courses = []
    for r in rows:
        v = session.execute(
            "SELECT title FROM videos_by_course WHERE course_id = %s LIMIT 1",
            (r["course_id"],),
        ).one()
        courses.append(
            {
                "course_id": r["course_id"],
                "title": v["title"] if v else r["course_id"],
                "global_friction_index": r["global_friction_index"],
            }
        )
    return courses


def get_course_detail(course_id):
    """Devuelve info del curso y la lista de videos con fricción."""
    videos = list(
        session.execute(
            """
            SELECT course_id, video_id, title, unit_topic, duration_seconds, video_url
            FROM videos_by_course
            WHERE course_id = %s
            """,
            (course_id,),
        )
    )
    if not videos:
        return None, None

    summaries = {
        str(r["video_id"]): r
        for r in session.execute(
            """
            SELECT video_id, friction_index, critical_segments_count
            FROM class_summary_by_course
            WHERE course_id = %s
            """,
            (course_id,),
        )
    }

    for v in videos:
        vid = str(v["video_id"])
        s = summaries.get(vid)
        v["friction_index"] = s["friction_index"] if s else None
        v["critical_segments_count"] = (
            s["critical_segments_count"] if s else None
        )

    return videos[0], videos  # primer video como cabecera


def get_video_detail(course_id, video_id_str):
    """Devuelve detalles del video, métricas por minuto y eventos."""
    try:
        video_id = UUID(video_id_str)
    except ValueError:
        return None, None, None

    video = session.execute(
        """
        SELECT course_id, video_id, title, unit_topic, duration_seconds, video_url
        FROM videos_by_course
        WHERE course_id = %s AND video_id = %s
        """,
        (course_id, video_id),
    ).one()
    if not video:
        return None, None, None

    metrics = list(
        session.execute(
            """
            SELECT minute_bucket, no_entiendo_count, muy_rapido_count,
                   ok_count, pause_count, seek_back_count
            FROM class_metrics_by_video_minute
            WHERE video_id = %s
            ORDER BY minute_bucket ASC
            """,
            (video_id,),
        )
    )

    # Para demo usamos ALLOW FILTERING
    events = list(
        session.execute(
            """
            SELECT student_id, event_time, event_type, second_mark, comment_text
            FROM experience_by_student_video
            WHERE video_id = %s ALLOW FILTERING
            """,
            (video_id,),
        )
    )

    return video, metrics, events


def get_student_profile(student_id_str):
    """Devuelve el perfil agregado y los eventos de un estudiante."""
    try:
        student_id = UUID(student_id_str)
    except ValueError:
        return None, None

    profile = list(
        session.execute(
            """
            SELECT topic_id, total_no_entiendo, total_critical_segments
            FROM student_profile_by_student
            WHERE student_id = %s
            """,
            (student_id,),
        )
    )

    events = list(
        session.execute(
            """
            SELECT video_id, event_time, event_type, second_mark, comment_text
            FROM experience_by_student_video
            WHERE student_id = %s ALLOW FILTERING
            """,
            (student_id,),
        )
    )

    return profile, events


# ---------- RUTAS FLASK ----------

@app.route("/")
def home():
    courses = get_courses()
    return render_template("index.html", courses=courses)

@app.route("/simulador_evento", methods=["GET", "POST"])
def simulador_evento():
    videos = get_all_videos()

    # IDs de ejemplo para no escribir a mano
    demo_students = [
        ("11111111-1111-1111-1111-111111111111", "Ana (Big Data)"),
        ("22222222-2222-2222-2222-222222222222", "Bruno (Cassandra)"),
        ("33333333-3333-3333-3333-333333333333", "Carla (Deep Learning)"),
    ]

    if request.method == "POST":
        student_id = request.form["student_id"]
        video_id = request.form["video_id"]
        event_type = request.form["event_type"]
        second_mark = request.form["second_mark"]
        comment_text = request.form["comment_text"]

        insert_student_event(student_id, video_id, event_type, second_mark, comment_text)
        # Después de guardar, redirigimos al detalle del video
        return redirect(
            url_for("video_detail",
                    course_id=request.form["course_id"],
                    video_id=video_id)
        )

    return render_template(
        "student_event.html",
        videos=videos,
        demo_students=demo_students,
    )


@app.route("/course/<course_id>")
def course_detail(course_id):
    header_video, videos = get_course_detail(course_id)
    if not videos:
        abort(404)
    return render_template(
        "course_detail.html",
        course_id=course_id,
        header_video=header_video,
        videos=videos,
    )

@app.route("/vista_estudiante_demo")
def vista_estudiante_demo():
    return render_template("student_player.html")


@app.route("/course/<course_id>/video/<video_id>")
def video_detail(course_id, video_id):
    video, metrics, events = get_video_detail(course_id, video_id)
    if not video:
        abort(404)
    return render_template(
        "video_detail.html",
        course_id=course_id,
        video=video,
        metrics=metrics,
        events=events,
    )


@app.route("/student/<student_id>")
def student_detail(student_id):
    profile, events = get_student_profile(student_id)
    if profile is None:
        abort(404)
    return render_template(
        "student_detail.html",
        student_id=student_id,
        profile=profile,
        events=events,
    )


if __name__ == "__main__":
    # Ojo: usamos 0.0.0.0:8080 para que funcione con el Preview de Cloud9
    app.run(host="0.0.0.0", port=8080, debug=True)
